package MyTest;

use Sub::Mage ':Class';

has x => ( is => 'rw', default => 7 );

1;
